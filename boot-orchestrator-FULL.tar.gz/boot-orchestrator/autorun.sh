#!/usr/bin/env bash
# autorun.sh — Linux launcher for boot-orchestrator.
# Checks for Go, fetches module dependencies, builds cmd/orchestrator, runs it.
set -euo pipefail

REQUIRED_GO_MAJOR=1
REQUIRED_GO_MINOR=22

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=== boot-orchestrator autorun (Linux) ==="

version_ge() {
    # returns 0 if $1 >= $2, comparing "major.minor" strings
    [ "$(printf '%s\n%s\n' "$1" "$2" | sort -V | head -n1)" = "$2" ]
}

if ! command -v go >/dev/null 2>&1; then
    echo "Go toolchain not found on PATH."
    echo "This script will not silently install system packages for you — install Go 1.22+ yourself:"
    echo "  https://go.dev/dl/"
    echo "On Debian/Ubuntu: sudo apt install golang-go   (verify version meets 1.22+; distro repos are often behind)"
    echo "On Fedora:        sudo dnf install golang"
    echo "On Arch:          sudo pacman -S go"
    exit 1
fi

GO_VER="$(go version | grep -oE 'go[0-9]+\.[0-9]+(\.[0-9]+)?' | sed 's/go//')"
GO_MAJOR_MINOR="$(echo "$GO_VER" | cut -d. -f1,2)"
if ! version_ge "$GO_MAJOR_MINOR" "${REQUIRED_GO_MAJOR}.${REQUIRED_GO_MINOR}"; then
    echo "Found Go $GO_VER, but this project requires Go ${REQUIRED_GO_MAJOR}.${REQUIRED_GO_MINOR}+."
    echo "Upgrade at: https://go.dev/dl/"
    exit 1
fi
echo "Go $GO_VER found — OK."

echo ""
echo "--- Fetching module dependencies (go mod download) ---"
go mod download

echo ""
echo "--- Building cmd/orchestrator ---"
mkdir -p bin
go build -o bin/boot-orchestrator ./cmd/orchestrator

echo ""
echo "--- Checking for privileged operations ---"
if [ "$(id -u)" -ne 0 ]; then
    echo "NOTE: partition, UEFI NVRAM, and low-level disk operations require root."
    echo "The TUI will start now in read-only/discovery mode; re-run with sudo when"
    echo "you're ready to actually provision a system:"
    echo "    sudo ./autorun.sh"
    echo ""
fi

echo "--- Launching boot-orchestrator ---"
exec ./bin/boot-orchestrator
