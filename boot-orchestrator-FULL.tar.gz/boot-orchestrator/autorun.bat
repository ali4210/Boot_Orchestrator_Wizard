@echo off
REM autorun.bat -- Windows launcher for boot-orchestrator.
REM Checks for Go, fetches module dependencies, builds cmd\orchestrator, runs it.
REM NOTE: this window stays open on exit (see "pause" calls below) so that
REM double-clicking from Explorer doesn't flash an error and disappear.

setlocal enabledelayedexpansion

echo === boot-orchestrator autorun (Windows) ===

where go >nul 2>nul
if errorlevel 1 (
    echo.
    echo [ERROR] Go toolchain not found on PATH.
    echo Install Go 1.22+ from https://go.dev/dl/ and re-run this script.
    echo Winget users can instead run: winget install GoLang.Go
    echo.
    echo After installing, CLOSE this window and open a NEW Command Prompt
    echo ^(so it picks up the updated PATH^) before running autorun.bat again.
    pause
    exit /b 1
)

for /f "tokens=3" %%v in ('go version') do set GOVERSTR=%%v
set GOVERSTR=%GOVERSTR:go=%
echo Found Go %GOVERSTR%

echo.
echo --- Fetching module dependencies (go mod download) ---
go mod download
if errorlevel 1 (
    echo.
    echo [ERROR] go mod download failed. Check your network connection and try again.
    pause
    exit /b 1
)

echo.
echo --- Building cmd\orchestrator ---
if not exist bin mkdir bin
go build -o bin\boot-orchestrator.exe .\cmd\orchestrator
if errorlevel 1 (
    echo.
    echo [ERROR] Build failed. See the error output above and fix it before re-running.
    pause
    exit /b 1
)

echo.
echo --- Checking for administrator privileges ---
net session >nul 2>nul
if errorlevel 1 (
    echo NOTE: partition, BCD, and low-level disk operations require Administrator.
    echo The TUI will start now in read-only/discovery mode; re-run this script
    echo from an elevated ^(Run as Administrator^) prompt when you're ready to
    echo actually provision a system.
    echo.
)

echo --- Launching boot-orchestrator ---
bin\boot-orchestrator.exe
if errorlevel 1 (
    echo.
    echo [ERROR] boot-orchestrator.exe exited with an error ^(see above^).
    pause
    exit /b 1
)

echo.
echo boot-orchestrator exited normally.
pause
endlocal

