package ui

import (
	"fmt"
	"strings"

	"github.com/charmbracelet/lipgloss"
)

const appTitle = " Universal OS, Storage & Hypervisor Orchestrator "

// View satisfies tea.Model.
func (m Model) View() string {
	if m.fatalErr != nil {
		return StyleDanger.Render(fmt.Sprintf("Fatal error loading catalog: %v\n", m.fatalErr))
	}

	header := StyleHeader.Render(appTitle)
	var body string

	switch m.screen {
	case ScreenWelcome:
		body = m.viewWelcome()
	case ScreenEnvironmentCheck:
		body = m.viewEnvironmentCheck()
	case ScreenOSSelect:
		body = m.viewOSSelect()
	case ScreenConfirm:
		body = m.viewConfirm()
	case ScreenProgress:
		body = m.viewProgress()
	case ScreenDone:
		body = m.viewDone()
	case ScreenError:
		body = m.viewError()
	}

	footer := StyleFooter.Render(m.footerHint())

	return lipgloss.JoinVertical(lipgloss.Left, header, "", body, "", footer)
}

func (m Model) footerHint() string {
	switch m.screen {
	case ScreenWelcome:
		return "enter: start   q: quit"
	case ScreenEnvironmentCheck:
		if m.envChecked {
			return "enter: continue   q: quit"
		}
		return "checking environment...   q: quit"
	case ScreenOSSelect:
		return "↑/↓: navigate   /: filter   enter: select   esc: back   q: quit"
	case ScreenConfirm:
		return "y/enter: confirm   n/esc: back"
	case ScreenProgress:
		return "please wait..."
	case ScreenDone, ScreenError:
		return "enter: exit"
	default:
		return "q: quit"
	}
}

func (m Model) viewWelcome() string {
	content := lipgloss.JoinVertical(lipgloss.Left,
		"Welcome. This wizard will:",
		"",
		"  1. Check your environment (hypervisor, firmware, disk, power)",
		"  2. Let you pick an OS from the universal catalog",
		"  3. Confirm and provision it",
		"",
		StyleMuted.Render("Press enter to begin."),
	)
	return StylePanel.Render(content)
}

func (m Model) viewEnvironmentCheck() string {
	if !m.envChecked {
		return StylePanel.Render("Running environment checks (hypervisor, firmware, disk headroom, power)...")
	}

	var b strings.Builder
	fmt.Fprintf(&b, "%s %s\n", StyleProgressLabel.Render("Hypervisor:"), m.hvInfo.Kind)
	fmt.Fprintf(&b, "%s %s\n\n", StyleProgressLabel.Render("Firmware:"), m.fwInfo.Mode)

	spaceStyle := StyleFlavorGUI
	spaceWord := "OK"
	if !m.guardReport.HasEnoughSpace {
		spaceStyle = StyleDanger
		spaceWord = "INSUFFICIENT"
	}
	fmt.Fprintf(&b, "%s %s (%s available, %s required)\n",
		StyleProgressLabel.Render("Disk headroom:"),
		spaceStyle.Render(spaceWord),
		FormatBytes(m.guardReport.AvailableBytes),
		FormatBytes(m.guardReport.RequiredBytes),
	)

	powerStyle := StyleFlavorGUI
	powerWord := "OK"
	if !m.guardReport.PowerOK {
		powerStyle = StyleDanger
		powerWord = "PLUG IN OR CHARGE ABOVE 50%"
	}
	fmt.Fprintf(&b, "%s %s\n", StyleProgressLabel.Render("Power:"), powerStyle.Render(powerWord))

	if m.envErr != nil {
		fmt.Fprintf(&b, "\n%s\n", StyleDanger.Render("Warning: "+m.envErr.Error()))
	}

	return StylePanel.Render(b.String())
}

func (m Model) viewOSSelect() string {
	return StylePanelFocused.Render(m.osList.View())
}

func (m Model) viewConfirm() string {
	if m.selectedOS == nil {
		return StylePanel.Render("No OS selected.")
	}
	e := *m.selectedOS

	flavorStyle := StyleFlavorGUI
	if e.Flavor == "tty" {
		flavorStyle = StyleFlavorTTY
	}

	var b strings.Builder
	fmt.Fprintf(&b, "You selected: %s %s\n\n", StyleProgressLabel.Render(e.Distro), e.Version)
	fmt.Fprintf(&b, "  Flavor: %s\n", flavorStyle.Render(string(e.Flavor)))
	fmt.Fprintf(&b, "  Arch:   %s\n", e.Arch)
	fmt.Fprintf(&b, "  Min disk: %d GB\n", e.MinDiskGB)
	if e.RequiresLicense {
		fmt.Fprintf(&b, "  %s\n", StyleWarningLine("Requires a valid license/product key"))
	}
	if e.EOL {
		fmt.Fprintf(&b, "  %s\n", StyleDanger.Render("This release is end-of-life / unsupported by upstream"))
	}
	if e.Notes != "" {
		fmt.Fprintf(&b, "\n  Note: %s\n", StyleMuted.Render(e.Notes))
	}
	fmt.Fprintf(&b, "\nProceed? (y/n)")

	return StylePanel.Render(b.String())
}

func StyleWarningLine(s string) string {
	return lipgloss.NewStyle().Foreground(lipgloss.Color("#FFB454")).Render(s)
}

func (m Model) viewProgress() string {
	pct := 0.0
	etaStr := "calculating..."
	if m.speed != nil {
		if p := m.speed.PercentComplete(); p >= 0 {
			pct = p / 100
		}
		d, ok := m.speed.ETA()
		etaStr = FormatETA(d, ok)
	}

	bar := m.progressBar.ViewAs(pct)
	label := StyleProgressLabel.Render(fmt.Sprintf("%.0f%%", pct*100))
	eta := StyleETA.Render("ETA: " + etaStr)

	return StylePanel.Render(lipgloss.JoinVertical(lipgloss.Left, bar, "", label+"   "+eta))
}

func (m Model) viewDone() string {
	return StylePanel.Render(StyleFlavorGUI.Render("✓ Complete.") + "\n\nPress enter to exit.")
}

func (m Model) viewError() string {
	msg := "An error occurred."
	if m.envErr != nil {
		msg = m.envErr.Error()
	}
	return StylePanel.Render(StyleDanger.Render("✗ " + msg))
}
