package ui

import "github.com/charmbracelet/lipgloss"

// Palette centralizes color choices so the whole TUI can be re-themed from
// one place, per the blueprint's "Theme/Layout Hub" requirement.
var (
	colorPrimary   = lipgloss.Color("#7D56F4") // purple accent
	colorSecondary = lipgloss.Color("#04B575") // green, success/GUI-flavor
	colorWarning   = lipgloss.Color("#FFB454") // amber, TTY-flavor / caution
	colorDanger    = lipgloss.Color("#FF5F5F") // red, destructive/errors
	colorMuted     = lipgloss.Color("#626262") // dim gray, secondary text
	colorText      = lipgloss.Color("#E4E4E4") // near-white body text
	colorBorder    = lipgloss.Color("#3A3A3A")
)

var (
	StyleHeader = lipgloss.NewStyle().
			Bold(true).
			Foreground(lipgloss.Color("#FAFAFA")).
			Background(colorPrimary).
			Padding(0, 2)

	StyleFooter = lipgloss.NewStyle().
			Foreground(colorMuted).
			Padding(0, 1)

	StylePanel = lipgloss.NewStyle().
			Border(lipgloss.RoundedBorder()).
			BorderForeground(colorBorder).
			Padding(1, 2)

	StylePanelFocused = StylePanel.
				BorderForeground(colorPrimary)

	StyleSelectedItem = lipgloss.NewStyle().
				Foreground(lipgloss.Color("#FAFAFA")).
				Background(colorPrimary).
				Bold(true).
				Padding(0, 1)

	StyleNormalItem = lipgloss.NewStyle().
			Foreground(colorText).
			Padding(0, 1)

	StyleFlavorTTY = lipgloss.NewStyle().Foreground(colorWarning).Bold(true)
	StyleFlavorGUI = lipgloss.NewStyle().Foreground(colorSecondary).Bold(true)

	StyleDanger = lipgloss.NewStyle().Foreground(colorDanger).Bold(true)
	StyleMuted  = lipgloss.NewStyle().Foreground(colorMuted)

	StyleProgressLabel = lipgloss.NewStyle().Foreground(colorText).Bold(true)
	StyleETA            = lipgloss.NewStyle().Foreground(colorMuted).Italic(true)
)
