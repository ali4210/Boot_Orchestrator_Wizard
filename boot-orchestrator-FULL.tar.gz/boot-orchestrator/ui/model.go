package ui

import (
	"time"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/bubbles/list"
	"github.com/charmbracelet/bubbles/progress"
	"github.com/charmbracelet/bubbles/textinput"

	"boot-orchestrator/discovery"
	"boot-orchestrator/hypervisor"
	"boot-orchestrator/safety"
)

// Screen identifies which step of the wizard is currently active. This is
// the Elm-architecture "current page" — Update() dispatches on this, View()
// renders based on it.
type Screen int

const (
	ScreenWelcome Screen = iota
	ScreenEnvironmentCheck
	ScreenOSSelect
	ScreenFlavorFilter
	ScreenConfirm
	ScreenProgress
	ScreenDone
	ScreenError
)

// osListItem adapts a discovery.Entry to bubbles/list's list.Item interface.
type osListItem struct {
	entry discovery.Entry
}

func (i osListItem) Title() string {
	return i.entry.Distro + " " + i.entry.Version
}

func (i osListItem) Description() string {
	flavor := string(i.entry.Flavor)
	if i.entry.RequiresLicense {
		flavor += ", license required"
	}
	if i.entry.EOL {
		flavor += ", EOL"
	}
	return string(i.entry.Family) + " / " + flavor + " / " + string(i.entry.Arch)
}

func (i osListItem) FilterValue() string {
	return i.entry.Distro + " " + i.entry.Version + " " + i.entry.Codename
}

// Model is the full application state.
type Model struct {
	screen Screen
	width  int
	height int

	// Environment & Safety Hub results (populated during ScreenEnvironmentCheck)
	hvInfo      hypervisor.Info
	fwInfo      safety.FirmwareInfo
	guardReport safety.GuardReport
	envErr      error
	envChecked  bool

	// Discovery Catalog
	catalog      *discovery.Catalog
	osList       list.Model
	selectedOS   *discovery.Entry
	searchInput  textinput.Model

	// Progress screen (wired to SpeedTracker from progress.go)
	progressBar progress.Model
	speed       *SpeedTracker

	// statusLog is the scrolling status journal shown on ScreenProgress and
	// ScreenError — one line per engine.StepUpdate received from
	// runProvision (see provision.go), plus any rollback outcome line.
	statusLog []string

	fatalErr error
}

// NewModel constructs the initial application state. It loads the embedded
// discovery catalog synchronously (fast, in-memory) but defers the
// environment checks (hypervisor/firmware/disk, which touch the filesystem
// and external commands) to a tea.Cmd so the UI can render an initial frame
// immediately instead of blocking startup on them.
func NewModel() Model {
	cat, err := discovery.LoadEmbedded()

	delegate := list.NewDefaultDelegate()
	l := list.New(nil, delegate, 0, 0)
	l.Title = "Select an Operating System"
	l.SetShowStatusBar(true)
	l.SetFilteringEnabled(true)

	if err == nil && cat != nil {
		items := make([]list.Item, 0, len(cat.Entries))
		for _, e := range cat.Entries {
			items = append(items, osListItem{entry: e})
		}
		l.SetItems(items)
	}

	ti := textinput.New()
	ti.Placeholder = "Search distros/versions..."
	ti.CharLimit = 64

	pb := progress.New(progress.WithDefaultGradient())

	return Model{
		screen:      ScreenWelcome,
		catalog:     cat,
		osList:      l,
		searchInput: ti,
		progressBar: pb,
		fatalErr:    err,
	}
}

// Init satisfies tea.Model.
func (m Model) Init() tea.Cmd {
	if m.fatalErr != nil {
		return nil
	}
	return nil
}

// --- Messages ---

type envCheckDoneMsg struct {
	hv    hypervisor.Info
	hvErr error
	fw    safety.FirmwareInfo
	fwErr error
	guard safety.GuardReport
	guardErr error
}

type tickMsg time.Time

// runEnvironmentChecks runs the real subsystem-1 checks off the UI thread
// via a tea.Cmd, so a slow `dmidecode` call or similar doesn't freeze
// rendering. This is genuinely wired to hypervisor.Detect(),
// safety.DetectFirmware(), and safety.CheckGuards() — not mocked.
func runEnvironmentChecks(targetPath string, footprintBytes uint64) tea.Cmd {
	return func() tea.Msg {
		hv, hvErr := hypervisor.Detect()
		fw, fwErr := safety.DetectFirmware()
		guard, guardErr := safety.CheckGuards(targetPath, footprintBytes)
		return envCheckDoneMsg{
			hv: hv, hvErr: hvErr,
			fw: fw, fwErr: fwErr,
			guard: guard, guardErr: guardErr,
		}
	}
}

func tickCmd() tea.Cmd {
	return tea.Tick(time.Millisecond*250, func(t time.Time) tea.Msg {
		return tickMsg(t)
	})
}

// Update satisfies tea.Model.
func (m Model) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {

	case tea.WindowSizeMsg:
		m.width, m.height = msg.Width, msg.Height
		listWidth := m.width - 4
		listHeight := m.height - 10
		if listWidth < 20 {
			listWidth = 20
		}
		if listHeight < 5 {
			listHeight = 5
		}
		m.osList.SetSize(listWidth, listHeight)
		m.progressBar.Width = listWidth
		return m, nil

	case tea.KeyMsg:
		switch msg.String() {
		case "ctrl+c", "q":
			if m.screen != ScreenOSSelect { // don't eat "q" while the user is typing a filter
				return m, tea.Quit
			}
		}
		return m.updateForScreen(msg)

	case envCheckDoneMsg:
		m.hvInfo = msg.hv
		m.fwInfo = msg.fw
		m.guardReport = msg.guard
		m.envChecked = true
		if msg.hvErr != nil {
			m.envErr = msg.hvErr
		} else if msg.fwErr != nil {
			m.envErr = msg.fwErr
		} else if msg.guardErr != nil {
			m.envErr = msg.guardErr
		}
		return m, nil

	case tickMsg:
		if m.screen == ScreenProgress {
			return m, tickCmd()
		}
		return m, nil
	}

	return m, nil
}

// updateForScreen dispatches key events to the currently active screen's
// own handling logic — the core of the Elm architecture's page routing.
func (m Model) updateForScreen(msg tea.KeyMsg) (tea.Model, tea.Cmd) {
	switch m.screen {

	case ScreenWelcome:
		if msg.String() == "enter" {
			m.screen = ScreenEnvironmentCheck
			return m, runEnvironmentChecks(".", 5*1024*1024*1024)
		}

	case ScreenEnvironmentCheck:
		if msg.String() == "enter" && m.envChecked {
			m.screen = ScreenOSSelect
		}

	case ScreenOSSelect:
		var cmd tea.Cmd
		m.osList, cmd = m.osList.Update(msg)
		if msg.String() == "enter" {
			if item, ok := m.osList.SelectedItem().(osListItem); ok {
				e := item.entry
				m.selectedOS = &e
				m.screen = ScreenConfirm
			}
		}
		if msg.String() == "esc" {
			m.screen = ScreenWelcome
		}
		return m, cmd

	case ScreenConfirm:
		switch msg.String() {
		case "y", "enter":
			m.screen = ScreenProgress
			m.speed = NewSpeedTracker(m.selectedOS.ApproxSizeBytes)
			return m, tickCmd()
		case "n", "esc":
			m.screen = ScreenOSSelect
		}

	case ScreenProgress:
		// Progress screen is driven by tickMsg + external progress updates
		// from the engine package (not yet implemented); no direct key
		// handling here besides the global quit binding.

	case ScreenDone, ScreenError:
		if msg.String() == "enter" {
			return m, tea.Quit
		}
	}

	return m, nil
}
